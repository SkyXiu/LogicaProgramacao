﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnmais_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Soma;
            resultado = varInteiro + varDecimal;
            MessageBox.Show("Soma: " + resultado);
        }

      

        private void btnmenos_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Subtração;
            resultado = varInteiro - varDecimal;
            MessageBox.Show("Subtração: " + resultado);
        }

        private void btnmulti_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Multiplicação;
            resultado = varInteiro * varDecimal;
            MessageBox.Show("Multiplicação: " + resultado);

        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            int varInteiro = int.Parse(txtInteiro.Text);
            float varDecimal = float.Parse(txtDecimal.Text);
            float resultado;

            //Divisão;
            resultado = varInteiro / varDecimal;
            MessageBox.Show("Divisão: " + resultado);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lblInteiro_Click(object sender, EventArgs e)
        {

        }

        private void lblDecimal_Click(object sender, EventArgs e)
        {

        }
    }
}
